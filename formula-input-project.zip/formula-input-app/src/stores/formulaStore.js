import { create } from 'zustand'

// Store for managing formula input state
export const useFormulaStore = create((set, get) => ({
  // Formula elements array - each element can be a tag, operator, number, or text
  elements: [],
  
  // Current cursor position in the formula
  cursorPosition: 0,
  
  // Active tag for dropdown interaction
  activeTagId: null,
  
  // Autocomplete suggestions
  suggestions: [],
  
  // Show autocomplete dropdown
  showAutocomplete: false,
  
  // Actions
  addElement: (element) => set((state) => {
    const newElements = [...state.elements]
    newElements.splice(state.cursorPosition, 0, element)
    return {
      elements: newElements,
      cursorPosition: state.cursorPosition + 1
    }
  }),
  
  removeElement: (index) => set((state) => ({
    elements: state.elements.filter((_, i) => i !== index),
    cursorPosition: Math.max(0, state.cursorPosition - 1)
  })),
  
  updateElement: (index, newElement) => set((state) => {
    const newElements = [...state.elements]
    newElements[index] = newElement
    return { elements: newElements }
  }),
  
  setCursorPosition: (position) => set({ cursorPosition: position }),
  
  setActiveTag: (tagId) => set({ activeTagId: tagId }),
  
  setSuggestions: (suggestions) => set({ suggestions }),
  
  setShowAutocomplete: (show) => set({ showAutocomplete: show }),
  
  // Clear all elements
  clearFormula: () => set({
    elements: [],
    cursorPosition: 0,
    activeTagId: null,
    suggestions: [],
    showAutocomplete: false
  }),
  
  // Get formula as string for calculation
  getFormulaString: () => {
    const state = get()
    return state.elements.map(element => {
      if (element.type === 'tag') return element.value || element.name
      if (element.type === 'operator') return element.value
      if (element.type === 'number') return element.value
      if (element.type === 'text') return element.value
      return ''
    }).join('')
  }
}))

