import { useQuery } from '@tanstack/react-query'

// API endpoint for autocomplete
const AUTOCOMPLETE_API = 'https://652f91320b8d8ddac0b2b62b.mockapi.io/autocomplete'

// Variable type prefixes
export const VARIABLE_PREFIXES = {
  NUMERIC: '#',
  PERCENTAGE: '%', 
  TIME: '⊙',
  CURRENCY: '$'
}

// Fetch autocomplete suggestions
export const fetchAutocompleteSuggestions = async (query) => {
  if (!query || query.length < 1) {
    return []
  }
  
  try {
    // Fetch all data from API since it doesn't support search filtering
    const response = await fetch(AUTOCOMPLETE_API)
    if (!response.ok) {
      throw new Error('Failed to fetch autocomplete suggestions')
    }
    const data = await response.json()
    
    // Filter data locally based on query
    const lowerQuery = query.toLowerCase()
    const filtered = data.filter(item => 
      item.name.toLowerCase().includes(lowerQuery) ||
      (item.category && item.category.toLowerCase().includes(lowerQuery))
    ).map(item => ({
      id: item.id,
      name: item.name,
      type: item.category || 'variable',
      description: `Category: ${item.category || 'N/A'}, Value: ${item.value || 'N/A'}`,
      value: item.value,
      prefix: VARIABLE_PREFIXES.NUMERIC // Default to numeric
    }))
    
    // Combine with fallback suggestions
    const fallbackSuggestions = getFallbackSuggestions(query)
    
    // Return combined results, prioritizing API results
    return [...filtered.slice(0, 5), ...fallbackSuggestions.slice(0, 10)]
  } catch (error) {
    console.error('Autocomplete API error:', error)
    // Return fallback suggestions if API fails
    return getFallbackSuggestions(query)
  }
}

// Hook for autocomplete suggestions
export const useAutocompleteSuggestions = (query, enabled = true) => {
  return useQuery({
    queryKey: ['autocomplete', query],
    queryFn: () => fetchAutocompleteSuggestions(query),
    enabled: enabled && query && query.length > 0,
    staleTime: 1000 * 60 * 2, // 2 minutes
  })
}

// Fallback suggestions when API is unavailable - matching Causal's variable types
const getFallbackSuggestions = (query) => {
  const fallbackData = [
    // Numeric variables (#)
    { id: 'f1', name: 'Sales cycle (months)', type: 'numeric', description: 'Sales cycle duration in months', prefix: VARIABLE_PREFIXES.NUMERIC },
    { id: 'f2', name: 'Contract length (months)', type: 'numeric', description: 'Contract duration in months', prefix: VARIABLE_PREFIXES.NUMERIC },
    { id: 'f3', name: 'Inbound leads (initial)', type: 'numeric', description: 'Initial inbound lead count', prefix: VARIABLE_PREFIXES.NUMERIC },
    { id: 'f4', name: 'Outbound messages sent', type: 'numeric', description: 'Number of outbound messages', prefix: VARIABLE_PREFIXES.NUMERIC },
    { id: 'f5', name: 'Existing customers (initial)', type: 'numeric', description: 'Initial customer count', prefix: VARIABLE_PREFIXES.NUMERIC },
    { id: 'f6', name: 'Demos', type: 'numeric', description: 'Number of demos', prefix: VARIABLE_PREFIXES.NUMERIC },
    { id: 'f7', name: 'Revenue', type: 'numeric', description: 'Total revenue', prefix: VARIABLE_PREFIXES.NUMERIC },
    { id: 'f8', name: 'Users', type: 'numeric', description: 'Number of users', prefix: VARIABLE_PREFIXES.NUMERIC },
    
    // Percentage variables (%)
    { id: 'f9', name: 'Churn rate', type: 'percentage', description: 'Customer churn rate', prefix: VARIABLE_PREFIXES.PERCENTAGE },
    { id: 'f10', name: 'Inbound lead growth', type: 'percentage', description: 'Inbound lead growth rate', prefix: VARIABLE_PREFIXES.PERCENTAGE },
    { id: 'f11', name: 'Conversion Rate', type: 'percentage', description: 'Conversion percentage', prefix: VARIABLE_PREFIXES.PERCENTAGE },
    { id: 'f12', name: 'Growth Rate', type: 'percentage', description: 'Growth percentage', prefix: VARIABLE_PREFIXES.PERCENTAGE },
    { id: 'f13', name: 'Meeting -> Demo', type: 'percentage', description: 'Meeting to demo conversion', prefix: VARIABLE_PREFIXES.PERCENTAGE },
    { id: 'f14', name: 'Demo -> Closed Won', type: 'percentage', description: 'Demo to closed won rate', prefix: VARIABLE_PREFIXES.PERCENTAGE },
    { id: 'f15', name: 'Outbound -> Meeting Booked', type: 'percentage', description: 'Outbound to meeting rate', prefix: VARIABLE_PREFIXES.PERCENTAGE },
    
    // Time/Period variables (⊙)
    { id: 'f16', name: 'month', type: 'time', description: 'Time period - month', prefix: VARIABLE_PREFIXES.TIME },
    { id: 'f17', name: 'quarter', type: 'time', description: 'Time period - quarter', prefix: VARIABLE_PREFIXES.TIME },
    { id: 'f18', name: 'year', type: 'time', description: 'Time period - year', prefix: VARIABLE_PREFIXES.TIME },
    { id: 'f19', name: 'this month', type: 'time', description: 'Current month period', prefix: VARIABLE_PREFIXES.TIME },
    { id: 'f20', name: 'previous month', type: 'time', description: 'Previous month period', prefix: VARIABLE_PREFIXES.TIME },
    
    // Currency variables ($)
    { id: 'f21', name: 'ACV', type: 'currency', description: 'Annual Contract Value', prefix: VARIABLE_PREFIXES.CURRENCY },
    { id: 'f22', name: 'MRR', type: 'currency', description: 'Monthly Recurring Revenue', prefix: VARIABLE_PREFIXES.CURRENCY },
    { id: 'f23', name: 'CAC', type: 'currency', description: 'Customer Acquisition Cost', prefix: VARIABLE_PREFIXES.CURRENCY },
    { id: 'f24', name: 'LTV', type: 'currency', description: 'Lifetime Value', prefix: VARIABLE_PREFIXES.CURRENCY },
  ]
  
  const lowerQuery = query.toLowerCase()
  return fallbackData.filter(item => 
    item.name.toLowerCase().includes(lowerQuery) ||
    item.description.toLowerCase().includes(lowerQuery) ||
    item.type.toLowerCase().includes(lowerQuery)
  )
}

